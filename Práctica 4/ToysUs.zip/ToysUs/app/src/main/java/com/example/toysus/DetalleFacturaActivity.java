package com.example.toysus;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Factura;
import com.example.toysus.modelos.Juguete;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DetalleFacturaActivity extends AppCompatActivity {

    final private String TAG = "Toys&US -> Factura";
    private TextView tvIdFactura, tvPagada, tvTotalPrecio, tvTipoPago, tvFechaEmis;
    private int idFact;
    private RequestQueue requestQueue;
    private Factura fact;
    private int id, unidades;
    private List<Juguete> juguetesComprados;
    private HashMap<Integer, Almacen> almacenes;
    private HashMap<Integer, Juguete> juguetes;

    private RecyclerView rvJuguetesComprados;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_factura);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Detalle factura");
        // Navegación hacia atrás
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        juguetes = new HashMap<>();
        almacenes = new HashMap<>();
        juguetesComprados = new ArrayList<>();

        // Fila de juguetes
        rvJuguetesComprados = (RecyclerView) findViewById(R.id.rvJuguetesComprados);
        layoutManager = new LinearLayoutManager(this);
        rvJuguetesComprados.setLayoutManager(layoutManager);
        rvJuguetesComprados.setItemAnimator(new DefaultItemAnimator());
        rvJuguetesComprados.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new DetalleFacturaRVAdapter(juguetesComprados, almacenes);
        rvJuguetesComprados.setAdapter(mAdapter);

        rvJuguetesComprados.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rvJuguetesComprados, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Log.d(TAG, "Click en " + position);
            }

            @Override
            public void onLongClick(View view, int position) {
                Log.d(TAG, "Long click en " + position);
            }
        }));

        // Campos de la factura
        tvIdFactura = (TextView) findViewById(R.id.tvIdFactura);
        tvPagada = (TextView) findViewById(R.id.tvPagada);
        tvTotalPrecio = (TextView) findViewById(R.id.tvTotalPrecio);
        tvTipoPago = (TextView) findViewById(R.id.tvTipoPago);
        tvFechaEmis = (TextView) findViewById(R.id.tvFechaEmis);
        // Id de la factura
        Intent i = getIntent();
        idFact = i.getIntExtra("idFact",0);
        requestQueue = Volley.newRequestQueue(getApplicationContext());

        // Obtenemos todos los juguetes
        JsonArrayRequest juguetesJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "juguetes",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            juguetes.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                juguetes.put(Integer.parseInt(objeto.get("id").toString()), new Juguete(
                                                Integer.parseInt(objeto.get("id").toString()),
                                                objeto.get("nombre").toString(),
                                                objeto.get("descripcion").toString(),
                                                Integer.parseInt(objeto.get("minEdadRecomendada").toString()),
                                                Double.parseDouble(objeto.get("precio").toString()),
                                                Integer.parseInt(objeto.get("almacen").toString()),
                                                Integer.parseInt(objeto.get("unidades").toString())
                                        )
                                );
                                Log.d(TAG, "Llega juguete " + objeto.toString());
                            }
                            getDetalleFactura();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a juguetes " + error.toString());
                    }
                }
        );
        requestQueue.add(juguetesJSONArray);

        // Obtenemos todos los almacenes
        JsonArrayRequest almacenesJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "almacenes",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            almacenes.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                almacenes.put(Integer.parseInt(objeto.get("id").toString()), new Almacen(
                                                Integer.parseInt(objeto.get("id").toString()),
                                                objeto.get("nombre").toString(),
                                                objeto.get("direccion").toString(),
                                                Double.parseDouble(objeto.get("lat").toString()),
                                                Double.parseDouble(objeto.get("lon").toString())
                                        )
                                );
                                Log.d(TAG, "Llega almacen " + objeto.toString());
                            }
                            getDetalleFactura();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a almacenes " + error.toString());
                    }
                }
        );
        requestQueue.add(almacenesJSONArray);
    }

    private void getDetalleFactura() {
        JsonObjectRequest facturaJSONObject = new JsonObjectRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "facturas/" + idFact,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            fact = new Factura(
                                    Integer.parseInt(response.get("id").toString()),
                                    Double.parseDouble(response.get("precio").toString()),
                                    Boolean.parseBoolean(response.get("pagado").toString()),
                                    response.get("idJuguetesComprados").toString(),
                                    response.get("fechaEmision").toString(),
                                    response.get("username").toString(),
                                    response.get("tipoPago").toString()
                            );
                            System.out.println(fact.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        actualizaVista();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a la factura id " + idFact + ": " + error.toString());
                    }
                }
        );

        requestQueue.add(facturaJSONObject);
    }

   /* private void getJuguetesComprados() {
        // Obtenemos los detalles de los juguetes comprados
        String[] elementos = (fact.getIdJuguetesComprados()).split(";");
        for (String s : elementos) {
            String[] bin = s.split(",");
            id = Integer.parseInt(bin[0]);
            unidades = Integer.parseInt(bin[1]);
            System.out.println("Id juguete comprado: " + id);
            JsonObjectRequest jugueteJSONObject = new JsonObjectRequest(
                    Request.Method.GET,
                    getString(R.string.url_servidor) + "juguetes/" + id,
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                j = new Juguete(
                                        Integer.parseInt(response.get("id").toString()),
                                        response.get("nombre").toString(),
                                        response.get("descripcion").toString(),
                                        Integer.parseInt(response.get("minEdadRecomendada").toString()),
                                        Double.parseDouble(response.get("precio").toString()),
                                        Integer.parseInt(response.get("almacen").toString()),
                                        Integer.parseInt(response.get("unidades").toString())
                                );
                                juguetesComprados.add(new Juguete(response.get("nombre").toString(), "", 0,
                                        Double.parseDouble(response.get("precio").toString()),
                                        Integer.parseInt(response.get("almacen").toString()), unidades));
                                System.out.println("Juguetes comprados");
                                for (Juguete j: juguetesComprados) {
                                    System.out.println(j.toString());
                                }
                                mAdapter.notifyDataSetChanged();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            JsonObjectRequest almacenJSONObject = new JsonObjectRequest(
                                    Request.Method.GET,
                                    getString(R.string.url_servidor) + "almacenes/" + j.getAlmacen(),
                                    null,
                                    new Response.Listener<JSONObject>() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            try {
                                                a = new Almacen(
                                                        Integer.parseInt(response.get("id").toString()),
                                                        response.get("nombre").toString(),
                                                        response.get("direccion").toString(),
                                                        Double.parseDouble(response.get("lat").toString()),
                                                        Double.parseDouble(response.get("lon").toString())
                                                );
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    },
                                    new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Log.e(TAG, "Error al llamar al almacen id " + j.getAlmacen() + ": " + error.toString());
                                        }
                                    }
                            );
                            requestQueue.add(almacenJSONObject);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e(TAG, "Error al llamar al juguete id " + id + ": " + error.toString());
                        }
                    }
            );

            requestQueue.add(jugueteJSONObject);
        }
    }*/

    private void actualizaVista() {
        tvIdFactura.setText(Integer.toString(fact.getId()));
        if (fact.getPagado()) tvPagada.setText("Sí");
        else tvPagada.setText("No");
        tvTotalPrecio.setText(new DecimalFormat("#.##").format(fact.getPrecio()) + "€");
        tvTipoPago.setText(fact.getTipoPago());
        tvFechaEmis.setText(fact.getFechaEmision());
        juguetesComprados.clear();
        // Mostramos solo los juguetes comprados
        String[] elementos = (fact.getIdJuguetesComprados()).split(";");
        for (String s : elementos) {
            String[] bin = s.split(",");
            id = Integer.parseInt(bin[0]);
            unidades = Integer.parseInt(bin[1]);
            juguetesComprados.add(new Juguete(id,
                    juguetes.get(id).getNombre(),
                    "",
                    0,
                    juguetes.get(id).getPrecio(),
                    juguetes.get(id).getAlmacen(),
                    unidades));
        }
        mAdapter.notifyDataSetChanged();
    }
}
