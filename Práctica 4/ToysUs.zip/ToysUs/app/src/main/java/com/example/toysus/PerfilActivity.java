package com.example.toysus;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Usuario;

import org.json.JSONException;
import org.json.JSONObject;

public class PerfilActivity extends AppCompatActivity {

    final private String TAG = "Toys&US -> Perfil";
    private RequestQueue requestQueue;
    private TextView tvUsername, tvResultado;
    private EditText nombre, clave1, clave2;
    private String username;
    private Button btGuardar;
    private String nuevoNombre, nuevaClave1, nuevaClave2;
    private Usuario u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // Navegación hacia atrás
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        // Campos del perfil
        tvUsername = (TextView) findViewById(R.id.tvUsername);
        tvResultado = (TextView) findViewById(R.id.tvResultado);
        nombre = (EditText) findViewById(R.id.tiNombre);
        clave1 = (EditText) findViewById(R.id.tiClave1);
        clave2 = (EditText) findViewById(R.id.tiClave2);
        btGuardar = (Button) findViewById(R.id.btGuardar);
        // Obtenemos los datos enviados
        btGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nuevoNombre = nombre.getText().toString();
                nuevaClave1 = clave1.getText().toString();
                nuevaClave2 = clave2.getText().toString();
                guardarPerfil();
            }
        });
        // Username del perfil
        Intent i = getIntent();
        username = i.getStringExtra("username");
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        // Ponemos su username y su nombre
        tvUsername.setText(username);
        JsonObjectRequest perfilJSONObject = new JsonObjectRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "usuarios/" + username,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            u = new Usuario(
                                    response.get("username").toString(),
                                    response.get("password").toString(),
                                    response.get("name").toString(),
                                    Double.parseDouble(response.get("lat").toString()),
                                    Double.parseDouble(response.get("lon").toString()),
                                    response.get("preferencias").toString(),
                                    response.get("carrito").toString(),
                                    Integer.parseInt(response.get("rol").toString())
                            );
                            nombre.setText(u.getName());
                            Log.d(TAG, "Perfil: llega usuario " + u.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al obtener el perfil del usuario  " + username + ": " + error.toString());
                    }
                }
        );
        requestQueue.add(perfilJSONObject);
    }

    private void guardarPerfil() {
        if (!nuevaClave1.equals(nuevaClave2)) {
            tvResultado.setText("Las contraseñas introducidas no coinciden.");
        }
        else {
            JSONObject nuevoPerfil = new JSONObject();
            try {
                nuevoPerfil.put("name", nuevoNombre);
                nuevoPerfil.put("password", nuevaClave1);

                JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST,
                        getString(R.string.url_servidor)+"usuarios/"+username, nuevoPerfil,
                        new Response.Listener<JSONObject>()
                        {
                            @Override
                            public void onResponse(JSONObject response) {
                                // response
                                Log.d("Response", response.toString());
                                finish();
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Log.d("Error.Response", error.toString());
                            }
                        }
                );
                requestQueue.add(postRequest);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
