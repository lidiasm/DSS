package com.example.toysus;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Factura;
import com.example.toysus.modelos.Juguete;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;

class FacturasRVAdapter extends RecyclerView.Adapter<FacturasRVAdapter.MyViewHolder> {
    List<Factura> facturas;
    HashMap<Integer, Almacen> almacenes;

    public FacturasRVAdapter(List<Factura> facturas) {
        this.facturas = facturas;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView id, precio, fechaEmision;

        public MyViewHolder(View view) {
            super(view);
            id = (TextView) view.findViewById(R.id.facturaId);
            precio = (TextView) view.findViewById(R.id.facturaPrecio);
            fechaEmision = (TextView) view.findViewById(R.id.facturaFechaEmision);
        }
    }

    class VHHeader extends RecyclerView.ViewHolder {
        public VHHeader(View itemView) {
            super(itemView);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.factura_fila, parent, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Factura f = facturas.get(position);
        holder.id.setText("Factura "+Integer.toString(f.getId()));
        holder.precio.setText(new DecimalFormat("#.##").format(f.getPrecio()) + "€");
        holder.fechaEmision.setText(f.getFechaEmision());
    }

    @Override
    public int getItemCount() {
        return facturas.size();
    }
}
