package com.example.toysus;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Juguete;
import com.example.toysus.modelos.Usuario;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {
    final private String TAG = "Toys&US -> Login";
    private RequestQueue requestQueue;

    private EditText tiUsername, tiPassword;
    private String username, password;
    private Button btLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        setTitle("Cuenta");
        requestQueue = Volley.newRequestQueue(getApplicationContext());

        tiUsername = (EditText) findViewById(R.id.tiUsername);
        tiPassword = (EditText) findViewById(R.id.tiPassword);

        btLogin = (Button) findViewById(R.id.btLogin);
        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = tiUsername.getText().toString();
                password = tiPassword.getText().toString();
                connect();
            }
        });

    }

    private void connect(){
        JsonObjectRequest loginJSONObject = new JsonObjectRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "usuarios/login/" + username + "/" + password,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            boolean login = response.getBoolean("login");
                            if (login){
                                JsonObjectRequest usuarioJSONObject = new JsonObjectRequest(
                                        Request.Method.GET,
                                        getString(R.string.url_servidor) + "usuarios/" + username,
                                        null,
                                        new Response.Listener<JSONObject>() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                try {
                                                    MainActivity.usuarioSesion = new Usuario(
                                                            response.getString("username"),
                                                            response.getString("password"),
                                                            response.getString("name"),
                                                            response.getDouble("lat"),
                                                            response.getDouble("lon"),
                                                            response.getString("preferencias"),
                                                            response.getString("carrito"),
                                                            response.getInt("rol")
                                                    );
                                                    finish();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }                    }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Log.e(TAG, "Error al llamar a login: " + error.toString());
                                            }
                                        }
                                );

                                requestQueue.add(usuarioJSONObject);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a login: " + error.toString());
                    }
                }
        );

        requestQueue.add(loginJSONObject);
    }
}
