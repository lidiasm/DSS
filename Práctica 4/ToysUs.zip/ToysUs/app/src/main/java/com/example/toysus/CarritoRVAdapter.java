package com.example.toysus;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Juguete;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;

class CarritoRVAdapter extends RecyclerView.Adapter<CarritoRVAdapter.MyViewHolder> {
    List<Juguete> juguetes;
    public CarritoRVAdapter(List<Juguete> juguetes) {
        this.juguetes = juguetes;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView nombre, unidades, precio;

        public MyViewHolder(View view) {
            super(view);
            nombre = (TextView) view.findViewById(R.id.cfNombre);
            unidades = (TextView) view.findViewById(R.id.cfUnidades);
            precio = (TextView) view.findViewById(R.id.cfPrecio);
        }
    }

    class VHHeader extends RecyclerView.ViewHolder {
        public VHHeader(View itemView) {
            super(itemView);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.carrito_fila, parent, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Juguete j = juguetes.get(position);
        double precio = j.getPrecio() * j.getUnidades();
        holder.nombre.setText(j.getNombre());
        holder.precio.setText(new DecimalFormat("#.##").format(precio) + "€");
        holder.unidades.setText(j.getUnidades()+"");
    }

    @Override
    public int getItemCount() {
        return juguetes.size();
    }
}
