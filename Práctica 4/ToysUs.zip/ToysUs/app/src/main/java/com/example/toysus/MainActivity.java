package com.example.toysus;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.support.v4.view.GravityCompat;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Juguete;
import com.example.toysus.modelos.Usuario;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    final private String TAG = "Toys&US -> Main";

    private List<Juguete> juguetes;
    private HashMap<Integer,Almacen> almacenes;

    private RecyclerView juguetesRV;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private RequestQueue requestQueue;

    private EditText tiBuscarJuguete;
    private Button btBuscar;

    public static Usuario usuarioSesion;
    private static Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        usuarioSesion = null;
        context = getApplicationContext();

        juguetes = new ArrayList<>();
        almacenes = new HashMap<>();

        requestQueue = Volley.newRequestQueue(getApplicationContext());

    }

    public void getJugetes(String busqueda){
        String url = getString(R.string.url_servidor) + "juguetes";
        if (!busqueda.equals("")) {
            url += "/buscar/"+busqueda;
        }

        JsonArrayRequest juguetesJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            juguetes.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                juguetes.add(new Juguete(
                                                Integer.parseInt(objeto.get("id").toString()),
                                                objeto.get("nombre").toString(),
                                                objeto.get("descripcion").toString(),
                                                Integer.parseInt(objeto.get("minEdadRecomendada").toString()),
                                                Double.parseDouble(objeto.get("precio").toString()),
                                                Integer.parseInt(objeto.get("almacen").toString()),
                                                Integer.parseInt(objeto.get("unidades").toString())
                                        )
                                );
                                Log.d(TAG, "Llega juguete " + objeto.toString());
                            }
                            mAdapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a juguetes " + error.toString());
                    }
                }
        );
        requestQueue.add(juguetesJSONArray);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Intent i;
        switch (id) {
            case R.id.conectar:
                i = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(i);
                break;
            case R.id.desconectar:
                MainActivity.updateUsuario();
                MainActivity.usuarioSesion = null;
                onResume();
                break;
            case  R.id.carrito:
                i = new Intent(getApplicationContext(), CarritoActivity.class);
                startActivity(i);
                break;
            case R.id.facturas:
                i = new Intent(getApplicationContext(), FacturasActivity.class);
                i.putExtra("username", MainActivity.usuarioSesion.getUsername());
                startActivity(i);
                break;
            case R.id.perfil:
                i = new Intent(getApplicationContext(), PerfilActivity.class);
                i.putExtra("username", MainActivity.usuarioSesion.getUsername());
                startActivity(i);
                break;
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MainActivity.usuarioSesion == null) {
            setContentView(R.layout.activity_main);
        } else {
            setContentView(R.layout.activity_main_user);
            Log.e(TAG, MainActivity.usuarioSesion.getName());
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        tiBuscarJuguete = (EditText) findViewById(R.id.tiBuscarJuguete);
        btBuscar = (Button) findViewById(R.id.btBuscar);
        btBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getJugetes(tiBuscarJuguete.getText().toString());
            }
        });

        juguetesRV = (RecyclerView) findViewById(R.id.rvJuguetes);
        layoutManager = new LinearLayoutManager(this);
        juguetesRV.setLayoutManager(layoutManager);
        juguetesRV.setItemAnimator(new DefaultItemAnimator());
        juguetesRV.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new JuguetesRVAdapter(juguetes, almacenes);
        juguetesRV.setAdapter(mAdapter);
        juguetesRV.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), juguetesRV, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Log.d(TAG, "Click en " + position);
                Intent i = new Intent(getApplicationContext(), JugueteActivity.class);
                i.putExtra("id", juguetes.get(position).getId());
                startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {
                Log.d(TAG, "Long click en " + position);
            }
        }));

        JsonArrayRequest almacenesJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "almacenes",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            almacenes.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                almacenes.put(Integer.parseInt(objeto.get("id").toString()),new Almacen(
                                        Integer.parseInt(objeto.get("id").toString()),
                                        objeto.get("nombre").toString(),
                                        objeto.get("direccion").toString(),
                                        Double.parseDouble(objeto.get("lat").toString()),
                                        Double.parseDouble(objeto.get("lon").toString())
                                ));
                                Log.d(TAG, "Llega almacen " + objeto.toString());
                            }
                            getJugetes("");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a juguetes " + error.toString());
                    }
                }
        );

        requestQueue.add(almacenesJSONArray);
    }

    public static void updateUsuario() {
        RequestQueue rq = Volley.newRequestQueue(context);
        String url = context.getString(R.string.url_servidor);
        url += "usuarios/" + MainActivity.usuarioSesion.getUsername();

        JSONObject aEnviar = new JSONObject();
        try {
            aEnviar.put("carrito", MainActivity.usuarioSesion.getCarrito());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url, aEnviar,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response) {
                        // response
                        Log.d("Response", response.toString());
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("Error.Response", error.toString());
                    }
                }
        );

        rq.add(postRequest);
    }
}

