package com.example.toysus;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Juguete;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CarritoActivity extends AppCompatActivity {
    final private String TAG = "Toys&US -> Carrito";
    private RequestQueue requestQueue;

    private RecyclerView rvCarrito;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private HashMap<Integer, Juguete> juguetes;
    private List<Juguete> aComprar;

    private Button btVaciar, btComprar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle("Carrito");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        juguetes = new HashMap<>();
        aComprar = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        btVaciar = (Button) findViewById(R.id.btVaciarCarrito);
        btVaciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.usuarioSesion.setCarrito("");
                MainActivity.updateUsuario();
                actualizarVista();
            }
        });

        btComprar = (Button) findViewById(R.id.btComprar);
        btComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ComprarActivity.class);
                startActivity(i);

            }
        });

        rvCarrito = (RecyclerView) findViewById(R.id.rvCarrito);
        layoutManager = new LinearLayoutManager(this);
        rvCarrito.setLayoutManager(layoutManager);
        rvCarrito.setItemAnimator(new DefaultItemAnimator());
        rvCarrito.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new CarritoRVAdapter(aComprar);
        rvCarrito.setAdapter(mAdapter);

        rvCarrito.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rvCarrito, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Log.d(TAG, "Click en " + position);
                eliminarJuguete(aComprar.get(position).getId());
            }

            @Override
            public void onLongClick(View view, int position) {
                Log.d(TAG, "Long click en " + position);
            }
        }));

        JsonArrayRequest juguetesJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "juguetes",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            juguetes.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                juguetes.put(Integer.parseInt(objeto.get("id").toString()), new Juguete(
                                                Integer.parseInt(objeto.get("id").toString()),
                                                objeto.get("nombre").toString(),
                                                objeto.get("descripcion").toString(),
                                                Integer.parseInt(objeto.get("minEdadRecomendada").toString()),
                                                Double.parseDouble(objeto.get("precio").toString()),
                                                Integer.parseInt(objeto.get("almacen").toString()),
                                                Integer.parseInt(objeto.get("unidades").toString())
                                        )
                                );
                                Log.d(TAG, "Llega juguete " + objeto.toString());
                            }
                            actualizarVista();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a juguetes " + error.toString());
                    }
                }
        );
        requestQueue.add(juguetesJSONArray);
    }

    private void eliminarJuguete(int id) {
        String carrito = MainActivity.usuarioSesion.getCarrito();
        if (carrito.length() == 0) {
            carrito = "";
        } else {
            String[] elementos = carrito.split(";");
            HashMap<Integer,Integer> productos = new HashMap<Integer, Integer>();
            for (String s : elementos) {
                String[] bin = s.split(",");
                productos.put(Integer.parseInt(bin[0]),Integer.parseInt(bin[1]));
            }

            if (productos.containsKey(id)) {
                int unidades = productos.get(id);
                unidades--;
                productos.put(id, unidades);
            }

            carrito = "";
            Iterator it = productos.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                if (Integer.parseInt(pair.getValue().toString()) != 0) {
                    carrito += pair.getKey() + "," + pair.getValue() + ";";
                }
                it.remove();
            }
            if (carrito.length() != 0)
                carrito = carrito.substring(0, carrito.length()-1);
        }
        MainActivity.usuarioSesion.setCarrito(carrito);
        MainActivity.updateUsuario();
        actualizarVista();
    }

    private void actualizarVista(){
        String carrito = MainActivity.usuarioSesion.getCarrito();
        aComprar.clear();
        if (carrito.length() != 0){
            String[] elementos = carrito.split(";");
            for (String s : elementos) {
                String[] bin = s.split(",");
                int id = Integer.parseInt(bin[0]);
                int unidades = Integer.parseInt(bin[1]);

                aComprar.add(new Juguete(id,
                        juguetes.get(id).getNombre(),
                        "",
                        0,
                        juguetes.get(id).getPrecio(),
                        0,
                        unidades));
            }
        }
        mAdapter.notifyDataSetChanged();

        if (carrito.length() == 0){
            btComprar.setEnabled(false);
        } else {
            btComprar.setEnabled(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!juguetes.isEmpty())
            actualizarVista();
    }
}
