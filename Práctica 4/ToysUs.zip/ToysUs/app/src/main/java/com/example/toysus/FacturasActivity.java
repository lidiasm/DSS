package com.example.toysus;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Factura;
import com.example.toysus.modelos.Juguete;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FacturasActivity extends AppCompatActivity {

    final private String TAG = "Toys&US -> Factura";
    private RequestQueue requestQueue;
    private RecyclerView facturasRV;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Factura> facturas;
    private HashMap<Integer,Almacen> almacenes;
    private String username;
    private Juguete j;
    private Almacen a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facturas);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Factura");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        facturas = new ArrayList<>();
        facturasRV = (RecyclerView) findViewById(R.id.rv_facturas);
        layoutManager = new LinearLayoutManager(this);
        facturasRV.setItemAnimator(new DefaultItemAnimator());
        facturasRV.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new FacturasRVAdapter(facturas);
        facturasRV.setAdapter(mAdapter);
        facturasRV.setLayoutManager(layoutManager);
        facturasRV.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), facturasRV, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Log.d(TAG, "Click en " + position);
                Intent i = new Intent(getApplicationContext(), DetalleFacturaActivity.class);
                i.putExtra("idFact", facturas.get(position).getId());
                startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {
                Log.d(TAG, "Long click en " + position);
            }
        }));

        Intent i = getIntent();
        username = i.getStringExtra("username");
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        getFacturas();
    }

    private void getFacturas(){
        String url = getString(R.string.url_servidor) + "facturas/username/" + username;
        JsonArrayRequest facturasJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            facturas.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                facturas.add(new Factura(
                                                Integer.parseInt(objeto.get("id").toString()),
                                                Double.parseDouble(objeto.get("precio").toString()),
                                                Boolean.parseBoolean(objeto.get("pagado").toString()),
                                                objeto.get("idJuguetesComprados").toString(),
                                                objeto.get("fechaEmision").toString(),
                                                objeto.get("username").toString(),
                                                objeto.get("tipoPago").toString()
                                        )
                                );
                                Log.d(TAG, "Llega factura " + objeto.toString());
                            }
                            // Obtenemos los juguetes de la factura
                            List<Integer> idsJuguetes = new ArrayList();
                            for (Factura f: facturas) {
                                String[] elementos = f.getIdJuguetesComprados().split(";");
                                for (String s : elementos) {
                                    String[] bin = s.split(",");
                                    int id = Integer.parseInt(bin[0]);
                                    // Sin juguetes repetidos
                                    if (idsJuguetes.contains(id) == false) {
                                        idsJuguetes.add(id);
                                    }
                                }
                            }
                            // Obtenemos la información de los juguetes
                            for (final Integer idJug: idsJuguetes) {

                                JsonObjectRequest jugueteJSONObject = new JsonObjectRequest(
                                        Request.Method.GET,
                                        getString(R.string.url_servidor) + "juguetes/" + idJug,
                                        null,
                                        new Response.Listener<JSONObject>() {
                                            @Override
                                            public void onResponse(JSONObject response) {
                                                try {
                                                    j = new Juguete(
                                                            Integer.parseInt(response.get("id").toString()),
                                                            response.get("nombre").toString(),
                                                            response.get("descripcion").toString(),
                                                            Integer.parseInt(response.get("minEdadRecomendada").toString()),
                                                            Double.parseDouble(response.get("precio").toString()),
                                                            Integer.parseInt(response.get("almacen").toString()),
                                                            Integer.parseInt(response.get("unidades").toString())
                                                    );
                                                    Log.d(TAG, "Llega juguete en factura " + j.toString());
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }

                                                JsonObjectRequest almacenJSONObject = new JsonObjectRequest(
                                                        Request.Method.GET,
                                                        getString(R.string.url_servidor) + "almacenes/" + j.getAlmacen(),
                                                        null,
                                                        new Response.Listener<JSONObject>() {
                                                            @Override
                                                            public void onResponse(JSONObject response) {
                                                                try {
                                                                    a = new Almacen(
                                                                            Integer.parseInt(response.get("id").toString()),
                                                                            response.get("nombre").toString(),
                                                                            response.get("direccion").toString(),
                                                                            Double.parseDouble(response.get("lat").toString()),
                                                                            Double.parseDouble(response.get("lon").toString())
                                                                    );
                                                                    Log.d(TAG, "Llega juguete en factura" + a.toString());
                                                                } catch (JSONException e) {
                                                                    e.printStackTrace();
                                                                }

                                                                //actualizaVista();
                                                            }
                                                        },
                                                        new Response.ErrorListener() {
                                                            @Override
                                                            public void onErrorResponse(VolleyError error) {
                                                                Log.e(TAG, "Error al llamar al almacen id " + j.getAlmacen() + ": " + error.toString());
                                                            }
                                                        }
                                                );
                                                requestQueue.add(almacenJSONObject);
                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Log.e(TAG, "Error al llamar al juguete id " + idJug + ": " + error.toString());
                                            }
                                        }
                                );
                                requestQueue.add(jugueteJSONObject);
                            }
                            mAdapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a facturas " + error.toString());
                    }
                }
        );
        requestQueue.add(facturasJSONArray);
    }
}
