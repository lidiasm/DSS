package com.example.toysus;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Juguete;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ComprarActivity extends AppCompatActivity {
    final private String TAG = "Toys&US -> Carrito";
    private RequestQueue requestQueue;

    private RecyclerView rvCarrito;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private HashMap<Integer, Juguete> juguetes;
    private List<Juguete> aComprar;

    private Button btCancelar, btComprar;
    private TextView tvTotalCompra;

    private RadioButton rbTransferencia, rbTarjeta, rbReembolso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comprar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle("Compra");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        juguetes = new HashMap<>();
        aComprar = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        tvTotalCompra = (TextView) findViewById(R.id.tvTotalCompra);

        rbTransferencia = (RadioButton) findViewById(R.id.rbTransferencia);
        rbTarjeta = (RadioButton) findViewById(R.id.rbTarjeta);
        rbTarjeta.setChecked(true);
        rbReembolso = (RadioButton) findViewById(R.id.rbReembolso);


        btCancelar = (Button) findViewById(R.id.btCancelar);
        btCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btComprar = (Button) findViewById(R.id.btComprar);
        btComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tipoPago = "";
                if (rbTransferencia.isChecked()){
                    tipoPago = "transferencia";
                }
                if (rbTarjeta.isChecked()){
                    tipoPago = "tarjeta";
                }
                if (rbReembolso.isChecked()){
                    tipoPago = "reembolso";
                }

                JSONObject aEnviar = new JSONObject();
                try {
                    aEnviar.put("username", MainActivity.usuarioSesion.getUsername());
                    aEnviar.put("tipoPago", tipoPago);

                    JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST,
                            getString(R.string.url_servidor)+"usuarios/comprar", aEnviar,
                            new Response.Listener<JSONObject>()
                            {
                                @Override
                                public void onResponse(JSONObject response) {
                                    // response
                                    Log.d("Response", response.toString());
                                    MainActivity.usuarioSesion.setCarrito("");
                                    finish();
                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // error
                                    Log.d("Error.Response", error.toString());
                                }
                            }
                    );
                    requestQueue.add(postRequest);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });

        rvCarrito = (RecyclerView) findViewById(R.id.rvCarrito);
        layoutManager = new LinearLayoutManager(this);
        rvCarrito.setLayoutManager(layoutManager);
        rvCarrito.setItemAnimator(new DefaultItemAnimator());
        rvCarrito.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new CarritoRVAdapter(aComprar);
        rvCarrito.setAdapter(mAdapter);

        rvCarrito.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), rvCarrito, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
            }

            @Override
            public void onLongClick(View view, int position) {
            }
        }));

        JsonArrayRequest juguetesJSONArray = new JsonArrayRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "juguetes",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            juguetes.clear();
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject objeto = response.getJSONObject(i);
                                juguetes.put(Integer.parseInt(objeto.get("id").toString()), new Juguete(
                                                Integer.parseInt(objeto.get("id").toString()),
                                                objeto.get("nombre").toString(),
                                                objeto.get("descripcion").toString(),
                                                Integer.parseInt(objeto.get("minEdadRecomendada").toString()),
                                                Double.parseDouble(objeto.get("precio").toString()),
                                                Integer.parseInt(objeto.get("almacen").toString()),
                                                Integer.parseInt(objeto.get("unidades").toString())
                                        )
                                );
                                Log.d(TAG, "Llega juguete " + objeto.toString());
                            }
                            actualizarVista();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar a juguetes " + error.toString());
                    }
                }
        );
        requestQueue.add(juguetesJSONArray);


    }

    private void actualizarVista(){
        String carrito = MainActivity.usuarioSesion.getCarrito();
        aComprar.clear();
        double total = 0;
        if (carrito.length() != 0){
            String[] elementos = carrito.split(";");
            for (String s : elementos) {
                String[] bin = s.split(",");
                int id = Integer.parseInt(bin[0]);
                int unidades = Integer.parseInt(bin[1]);

                aComprar.add(new Juguete(id,
                        juguetes.get(id).getNombre(),
                        "",
                        0,
                        juguetes.get(id).getPrecio(),
                        0,
                        unidades));
                total += juguetes.get(id).getPrecio() * unidades;
            }
        }

        tvTotalCompra.setText(new DecimalFormat("#.##").format(total) + "€");
        mAdapter.notifyDataSetChanged();
    }
}
