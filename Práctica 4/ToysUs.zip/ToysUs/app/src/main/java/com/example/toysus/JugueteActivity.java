package com.example.toysus;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Usuario;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


import com.example.toysus.modelos.Juguete;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class JugueteActivity extends AppCompatActivity implements OnMapReadyCallback {
    final private String TAG = "Toys&US -> Juguete";
    private RequestQueue requestQueue;

    private int idJ;
    private Juguete j;
    private Almacen a;

    private TextView tvNombre, tvDescripcion, tvEdad, tvPrecio, tvUnidades;
    private GoogleMap mMap;
    private Button btComprar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juguete);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle("Detalle juguete");
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        tvNombre = (TextView) findViewById(R.id.tvNombre);
        tvDescripcion = (TextView) findViewById(R.id.tvDescripcion);
        tvEdad = (TextView) findViewById(R.id.tvEdad);
        tvPrecio = (TextView) findViewById(R.id.tvPrecio);
        tvUnidades = (TextView) findViewById(R.id.tvUnidades);

        btComprar = (Button) findViewById(R.id.btComprar);

        Intent i = getIntent();
        idJ = i.getIntExtra("id",0);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        requestQueue = Volley.newRequestQueue(getApplicationContext());


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        getData();
    }

    public void getData(){
        JsonObjectRequest jugueteJSONObject = new JsonObjectRequest(
                Request.Method.GET,
                getString(R.string.url_servidor) + "juguetes/" + idJ,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            j = new Juguete(
                                    Integer.parseInt(response.get("id").toString()),
                                    response.get("nombre").toString(),
                                    response.get("descripcion").toString(),
                                    Integer.parseInt(response.get("minEdadRecomendada").toString()),
                                    Double.parseDouble(response.get("precio").toString()),
                                    Integer.parseInt(response.get("almacen").toString()),
                                    Integer.parseInt(response.get("unidades").toString())
                            );
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        JsonObjectRequest almacenJSONObject = new JsonObjectRequest(
                                Request.Method.GET,
                                getString(R.string.url_servidor) + "almacenes/" + j.getAlmacen(),
                                null,
                                new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject response) {
                                        try {
                                            a = new Almacen(
                                                    Integer.parseInt(response.get("id").toString()),
                                                    response.get("nombre").toString(),
                                                    response.get("direccion").toString(),
                                                    Double.parseDouble(response.get("lat").toString()),
                                                    Double.parseDouble(response.get("lon").toString())
                                            );
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }

                                        actualizaVista();
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Log.e(TAG, "Error al llamar al almacen id " + j.getAlmacen() + ": " + error.toString());
                                    }
                                }
                        );
                        requestQueue.add(almacenJSONObject);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error al llamar al juguete id " + idJ + ": " + error.toString());
                    }
                }
        );

        requestQueue.add(jugueteJSONObject);
    }

    public void actualizaVista(){
        tvNombre.setText(j.getNombre());
        tvDescripcion.setText(j.getDescripcion());
        tvEdad.setText(j.getMinEdadRecomendada()+"");
        tvPrecio.setText(new DecimalFormat("#.##").format(j.getPrecio()) + "€");
        tvUnidades.setText(j.getUnidades()+"");

        LatLng almacen = new LatLng(a.getLat(), a.getLon());
        mMap.addMarker(new MarkerOptions().position(almacen)
                .title(a.getNombre()));

        if (MainActivity.usuarioSesion != null){
            LatLng usuario = new LatLng(MainActivity.usuarioSesion.getLat(), MainActivity.usuarioSesion.getLon());
            mMap.addMarker(new MarkerOptions().position(usuario)
                    .title(MainActivity.usuarioSesion.getUsername())
            .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.ic_location_on_user_24dp)));
        }

        mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(38,-4)));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(6));
    }

    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (j != null && a != null) {
            actualizaVista();
        }
        if (MainActivity.usuarioSesion == null){
            btComprar.setText("Conectar");
            btComprar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(i);
                }
            });
        } else {
            btComprar.setText("Añadir a cesta");
            btComprar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    buy();
                }
            });
        }
        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (MainActivity.usuarioSesion != null) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.carrito, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_carrito) {
            Intent i = new Intent(getApplicationContext(), CarritoActivity.class);
            startActivity(i);
        }

        return true;
    }

    private void buy(){
        Log.d(TAG, "Comprar " + idJ);

        String carrito = MainActivity.usuarioSesion.getCarrito();
        if (carrito.length() == 0) {
            carrito = idJ+",1";
        } else {
            String[] elementos = carrito.split(";");
            HashMap<Integer,Integer> productos = new HashMap<Integer, Integer>();
            for (String s : elementos) {
                String[] bin = s.split(",");
                productos.put(Integer.parseInt(bin[0]),Integer.parseInt(bin[1]));
            }

            if (productos.containsKey(idJ)) {
                int unidades = productos.get(idJ);
                unidades++;
                productos.put(idJ, unidades);
            } else {
                productos.put(idJ, 1);
            }

            carrito = "";
            Iterator it = productos.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                carrito += pair.getKey() + "," + pair.getValue() + ";";
                it.remove();
            }

            carrito = carrito.substring(0, carrito.length()-1);
        }
        MainActivity.usuarioSesion.setCarrito(carrito);
        MainActivity.updateUsuario();
    }
}
