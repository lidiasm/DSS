package com.example.toysus;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.toysus.modelos.Almacen;
import com.example.toysus.modelos.Juguete;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;

class DetalleFacturaRVAdapter extends RecyclerView.Adapter<DetalleFacturaRVAdapter.MyViewHolder> {
    List<Juguete> juguetes;
    HashMap<Integer, Almacen> almacenes;

    public DetalleFacturaRVAdapter(List<Juguete> juguetes, HashMap<Integer, Almacen> almacenes) {
        this.juguetes = juguetes;
        this.almacenes = almacenes;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView nombre, precio, almacen, unidades;

        public MyViewHolder(View view) {
            super(view);
            nombre = (TextView) view.findViewById(R.id.dfNombreJug);
            precio = (TextView) view.findViewById(R.id.dfPrecioJug);
            almacen = (TextView) view.findViewById(R.id.dfAlmacenJug);
            unidades = (TextView) view.findViewById(R.id.dfUnidadesJug);
        }
    }

    class VHHeader extends RecyclerView.ViewHolder {
        public VHHeader(View itemView) {
            super(itemView);
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.detalle_factura_fila, parent, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Juguete j = juguetes.get(position);
        holder.nombre.setText(j.getNombre());
        holder.precio.setText(new DecimalFormat("#.##").format(j.getPrecio()) + "€");
        holder.almacen.setText(almacenes.get(j.getAlmacen()).getNombre());
        //holder.almacen.setText(Integer.toString(j.getAlmacen()));
        holder.unidades.setText(Integer.toString(j.getUnidades()) + " ud.");
    }

    @Override
    public int getItemCount() {
        return juguetes.size();
    }
}
