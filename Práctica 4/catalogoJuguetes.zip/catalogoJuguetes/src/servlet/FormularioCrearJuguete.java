package servlet;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

@WebServlet("/formularioCrearJuguete")
public class FormularioCrearJuguete extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public FormularioCrearJuguete() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			Client client = ClientBuilder.newClient();
	        
	        WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/almacenes/");
	        String respuesta = OrderByIdTarget.request().get(String.class);
	        
	        if (respuesta == "null") {
	        	throw new Exception();
	        }
	        
	        JSONArray json = (JSONArray) JSONValue.parse(respuesta);
	        String select = "";
	        Iterator lista = json.iterator();
	        while (lista.hasNext()) { 
	        	JSONObject objeto = (JSONObject)lista.next();
	        	select += "<option value=" + Integer.parseInt(objeto.get("id").toString())+">"+objeto.get("nombre").toString()+"</option>";
	        }

	        request.setAttribute("select", select);
	        RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/forms/crear_juguete.jsp");
	        dispatcher.forward(request, response);
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}

}
