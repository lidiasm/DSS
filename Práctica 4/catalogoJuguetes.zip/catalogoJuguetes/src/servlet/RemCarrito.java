package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class RemCarrito
 */
@WebServlet("/usuario/remCarrito")
public class RemCarrito extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public RemCarrito() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			int id = Integer.parseInt(request.getParameter("id"));
			String username = request.getSession().getAttribute("username").toString();
			
			Client client = ClientBuilder.newClient();
	        
	        WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/usuarios/"+username);
	        String respuesta = OrderByIdTarget.request().get(String.class);
	        
	        if (respuesta == "null") {
	        	throw new Exception();
	        }
	        
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        
	        String carrito = json.get("carrito").toString();
	        if (carrito.length() == 0) {
	        	carrito = "";
	        } else {
		        String[] elementos = carrito.split(";");
		        HashMap<Integer,Integer> productos = new HashMap<Integer, Integer>();
		        for (String s : elementos) {
					String[] bin = s.split(",");
					productos.put(Integer.parseInt(bin[0]),Integer.parseInt(bin[1]));
				}
		        
		        if (productos.containsKey(id)) {
		        	int unidades = productos.get(id);
		        	unidades--;
		        	productos.put(id, unidades);
		        }
		        
		        carrito = "";
		        Iterator it = productos.entrySet().iterator();
		        while (it.hasNext()) {
		            Map.Entry pair = (Map.Entry)it.next();
		            if (Integer.parseInt(pair.getValue().toString()) != 0) {
		            	carrito += pair.getKey() + "," + pair.getValue() + ";";
		            }
		            it.remove();
		        }
		        if (carrito.length() != 0)
		        	carrito = carrito.substring(0, carrito.length()-1);
	        }
	        
	        
	        OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/usuarios/"+username);
	        Response res = OrderByIdTarget.request(MediaType.APPLICATION_JSON).post(Entity.json("{\"carrito\":\""+carrito+"\"}"));
	        respuesta = res.readEntity(String.class);
	        json = (JSONObject) JSONValue.parse(respuesta);
	        
	        response.sendRedirect(request.getHeader("Referer"));
	        
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/usuario");
		}
	}

}
