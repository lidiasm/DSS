package servlet;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class PassRecovery
 */
@WebServlet("/passRecovery")
public class PassRecovery extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public PassRecovery() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = (String) request.getParameter("username");
			if (username == null) {
				throw new Exception();
			}

			Client client = ClientBuilder.newClient();
			WebTarget OrderByIdTarget = client
					.target("http://localhost:8080/catalogoJuguetes/rest/usuarios/" + username);
			String respuesta = OrderByIdTarget.request().get(String.class);

			if (respuesta == "null") {
				throw new Exception();
			}

			JSONObject json = (JSONObject) JSONValue.parse(respuesta);

			String token = json.get("password").toString().substring(0,30) + "#" + username;
			
			String url = "http://localhost:8080/catalogoJuguetes/recuperarPass?token=" + Base64.getEncoder().encodeToString(token.getBytes());

			request.setAttribute("url", url);

			RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/templates/recover.jsp");
			dispatcher.forward(request, response);

		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}

}
