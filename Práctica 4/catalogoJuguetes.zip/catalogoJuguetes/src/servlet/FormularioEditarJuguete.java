package servlet;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import modelo.Juguete;

@WebServlet(urlPatterns = { "/formularioEditarJuguete" })
public class FormularioEditarJuguete extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public FormularioEditarJuguete() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String id = (String) request.getParameter("id");
			// Obtenemos el juguete
	    	String idJuguete = (String) request.getParameter("id");
	    	Client client = ClientBuilder.newClient();
			WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/juguetes/"+idJuguete);
	        String respuesta = OrderByIdTarget.request().get(String.class);
	        
	        JSONObject objeto = (JSONObject) JSONValue.parse(respuesta);
	    	Juguete jugueteAEditar = new Juguete(
				Integer.parseInt(objeto.get("id").toString()), 
				objeto.get("nombre").toString(), 
				objeto.get("descripcion").toString(),
				Integer.parseInt(objeto.get("minEdadRecomendada").toString()),
				Double.parseDouble(objeto.get("precio").toString()),
				Integer.parseInt(objeto.get("almacen").toString()),
				Integer.parseInt(objeto.get("unidades").toString())
				);
	    	
			client = ClientBuilder.newClient();
	        
	        OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/almacenes/");
	        respuesta = OrderByIdTarget.request().get(String.class);
	        
	        if (respuesta == "null") {
	        	throw new Exception();
	        }
	        
	        JSONArray json = (JSONArray) JSONValue.parse(respuesta);
	        String select = "";
	        Iterator lista = json.iterator();
	        while (lista.hasNext()) { 
	        	objeto = (JSONObject)lista.next();
	        	if (jugueteAEditar.getAlmacen() == Integer.parseInt(objeto.get("id").toString())) {
	        		select += "<option value=" + Integer.parseInt(objeto.get("id").toString())+" selected>"+objeto.get("nombre").toString()+"</option>";
	        	}
	        	else {
	        		select += "<option value=" + Integer.parseInt(objeto.get("id").toString())+">"+objeto.get("nombre").toString()+"</option>";
	        	}
	        }

	        RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/editarJuguete?id="+id+"&select="+select);
	        dispatcher.forward(request, response);
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}

}
