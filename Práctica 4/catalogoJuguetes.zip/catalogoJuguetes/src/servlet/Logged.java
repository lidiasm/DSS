package servlet;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class Logged
 */
@WebServlet("/logged")
public class Logged extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logged() {
        super();
    }

    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = (String) request.getParameter("username");
			String password = (String) request.getParameter("password");
			
			Client client = ClientBuilder.newClient();
	        
	        WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/usuarios/login/"+username+"/"+password);
	        String respuesta = OrderByIdTarget.request().get(String.class);
	        
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        boolean loggedIn = json.get("login").toString() == "true";
	        
	        if (loggedIn) {
	        	// Poner en la sesión los datos
	        	OrderByIdTarget = client.target(
	    				"http://localhost:8080/catalogoJuguetes/rest/usuarios/"+username);
	    	    respuesta = OrderByIdTarget.request().get(String.class);
	    	    json = (JSONObject) JSONValue.parse(respuesta);
	    	        	    
	        	request.getSession().setAttribute("username", username);
	        	request.getSession().setAttribute("name", json.get("name"));
	        	request.getSession().setAttribute("rol", json.get("rol"));
	        	request.getSession().setAttribute("preferencias", json.get("preferencias"));
	        	
	        	if(request.getSession().getAttribute("lastPageSR") != null){
	        		String url = request.getSession().getAttribute("lastPageSR").toString();
	        		request.getSession().removeAttribute("lastPageSR");
	        		response.sendRedirect(url);
	        	} else {
	        		response.sendRedirect("/catalogoJuguetes/");
	        	}
	        } else {
	    		response.sendRedirect("/catalogoJuguetes/login.jsp");
	        }
	        
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/login.jsp");
		}
	}

}
