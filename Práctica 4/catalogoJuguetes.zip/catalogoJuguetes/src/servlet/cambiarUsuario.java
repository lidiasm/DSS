package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class cambiarUsuario
 */
@WebServlet("/usuario/cambiar")
public class cambiarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public cambiarUsuario() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = request.getSession().getAttribute("username").toString();
			String password = (String) request.getParameter("password");
			String password1 = (String) request.getParameter("password1");
			String name = (String) request.getParameter("name");
			String preferencias = (String) request.getParameter("preferencias");
			
			if (!password.equals(password1)) {
				throw new Exception();
			}
			
			Client client = ClientBuilder.newClient();
			
	        WebTarget OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/usuarios/"+username);
	        
	        String jsonEnvio = "{";
	        jsonEnvio += "\"name\": \""+name+"\",";
	        jsonEnvio += "\"preferencias\": \""+preferencias+"\"";
	        if (!password.equals(""))
	        	jsonEnvio += ",\"password\": \""+password+"\"";
	        jsonEnvio += "}";
	        
	        
	        Response res = OrderByIdTarget.request(MediaType.APPLICATION_JSON).post(Entity.json(jsonEnvio));
	        String respuesta = res.readEntity(String.class);
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        boolean changed = json.get("updated").toString() == "true";
	        
	        if (!changed) {
	        	throw new Exception();
	        }
	        
	        request.getSession().setAttribute("name", name);
	        request.getSession().setAttribute("preferencias", preferencias);
	        
	        response.sendRedirect("/catalogoJuguetes/usuario/perfil.jsp");
	        
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}

}
