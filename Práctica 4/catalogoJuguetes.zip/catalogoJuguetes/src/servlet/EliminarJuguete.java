package servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

@WebServlet(urlPatterns = { "/eliminarJuguete" })
public class EliminarJuguete extends HttpServlet {

private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EliminarJuguete() {
        super();
    }

    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			// Obtenemos los parámetros
			String id = (String) request.getParameter("id");
			
			Client client = ClientBuilder.newClient();
	        
	        WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/juguetes/"+id);
	        Response res = OrderByIdTarget.request(MediaType.APPLICATION_JSON).delete(Response.class);
	        String respuesta = res.readEntity(String.class);
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        boolean created = json.get("deleted").toString() == "true";
	        
	        if (!created) {
	        	throw new Exception();
	        }
	        
	        response.sendRedirect("/catalogoJuguetes/juguetes");
	        
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}
	
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
        doPost(request, response);
    }
}

