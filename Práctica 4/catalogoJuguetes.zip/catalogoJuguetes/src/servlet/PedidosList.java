package servlet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import modelo.Juguete;

/**
 * Servlet implementation class PedidosList
 */
@WebServlet("/usuario/pedidos")
public class PedidosList extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PedidosList() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = request.getSession().getAttribute("username").toString();

			Client client = ClientBuilder.newClient();
	        WebTarget OrderByIdTarget;
	        String respuesta;
	        
	        // Traemos los alamacenes para poner su nombre
	        OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/almacenes");
		    respuesta = OrderByIdTarget.request().get(String.class);
		        
	        JSONArray jsonls = (JSONArray) JSONValue.parse(respuesta);
	        HashMap<Integer, String> almacenes = new HashMap<Integer, String>();
	        
	        Iterator lista = jsonls.iterator();
	        while (lista.hasNext())  
	        { 
	        	JSONObject objeto = (JSONObject)lista.next();
	        	almacenes.put(Integer.parseInt(objeto.get("id").toString()), objeto.get("nombre").toString());
	        } 
	        
        	// Obtenemos los pedidos realizados por el usuario
	        OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/usuarios/pedidos/"+username);
	        String idsJuguetesComprados = (OrderByIdTarget.request().get(String.class)).replace("\"", "");;
		    String[] elementos = idsJuguetesComprados.split(";");
	        List<Juguete> juguetesComprados = new ArrayList();
	        for (String id : elementos) {
	        	// Obtenemos los datos de los juguetes comprados
	        	OrderByIdTarget = client.target(
						"http://localhost:8080/catalogoJuguetes/rest/juguetes/"+id);
			    respuesta = OrderByIdTarget.request().get(String.class);
			    JSONObject json = (JSONObject) JSONValue.parse(respuesta);
			    juguetesComprados.add(new Juguete(Integer.parseInt(id), json.get("nombre").toString(), json.get("descripcion").toString(), 
		    		Integer.parseInt(json.get("minEdadRecomendada").toString()), Double.parseDouble(json.get("precio").toString()),
		    		Integer.parseInt(json.get("almacen").toString()), Integer.parseInt(json.get("unidades").toString())));
	        }
	        // Visualización de los juguetes comprados
	        String tabla = "<div class=\"row justify-content-md-center mt-3\">";
        	tabla += "<div class=\"col-md-8\">";
        	tabla += "<div class=\"row\">";
        	tabla += "<div class=\"col-md-12\">";
        	tabla += "<h3>Pedidos<h3>";
        	tabla += "</div>";
        	tabla += "</div>";
        	tabla += "<div class=\"row\">";
        	tabla += "<div class=\"col-md-12\">";
        	tabla += "<table style=\"width: 100%;\">";
        	tabla += "<thead>";
        	tabla += "<tr>";
        	tabla += "<th scope=\"col\">Juguete</th>";
        	tabla += "<th scope=\"col\">Descripción</th>";
        	tabla += "<th scope=\"col\">Mínima edad</th>";
        	tabla += "<th scope=\"col\">Precio</th>";
        	tabla += "<th scope=\"col\">Almacén</th>";
        	tabla += "</tr>";
        	tabla += "</thead>";
        	tabla += "<tbody>";
	        for (Juguete jug: juguetesComprados) {
	        	tabla += "<tr>";
	        	tabla += "<td>"+jug.getNombre()+"</td>";
	        	tabla += "<td>"+jug.getDescripcion()+"</td>";
	        	tabla += "<td>"+jug.getMinEdadRecomendada()+"</td>";
	        	tabla += "<td>"+jug.getPrecio()+"</td>";
	        	tabla += "<td>"+almacenes.get(jug.getAlmacen())+"</td>";
	        	tabla += "</tr>";
	        }
	        tabla += "</tbody>";
        	tabla += "</table>";
        	tabla += "</div>";
        	tabla += "</div>";
        	tabla += "</div>";
        	tabla += "</div>";
        	
        	// Visualizamos los pedidos
        	request.setAttribute("tabla", tabla);
	        RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/templates/pedidos.jsp");
	        dispatcher.forward(request, response);
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/usuario/perfil.jsp");
		}
	}

}

