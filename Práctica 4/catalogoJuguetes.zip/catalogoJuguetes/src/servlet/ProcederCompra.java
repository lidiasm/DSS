package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class ProcederCompra
 */
@WebServlet("/usuario/procederCompra")
public class ProcederCompra extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ProcederCompra() {
        super();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = request.getSession().getAttribute("username").toString();
			String pago = (String) request.getParameter("pago");

			Client client = ClientBuilder.newClient();
			
	        WebTarget OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/usuarios/comprar");
	        
	        String jsonEnvio = "{";
	        jsonEnvio += "\"username\": \""+username+"\",";
	        jsonEnvio += "\"tipoPago\": \""+pago+"\"";
	        jsonEnvio += "}";
	        
	        
	        Response res = OrderByIdTarget.request(MediaType.APPLICATION_JSON).post(Entity.json(jsonEnvio));
	        String respuesta = res.readEntity(String.class);
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        boolean changed = json.get("bought").toString() == "true";
	        
	        if (!changed) {
	        	throw new Exception();
	        }
	        
	        response.sendRedirect("/catalogoJuguetes/usuario/facturas");
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/usuario/perfil.jsp");
		}
	}

}
