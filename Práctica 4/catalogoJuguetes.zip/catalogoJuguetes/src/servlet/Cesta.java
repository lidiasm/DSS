package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class Cesta
 */
@WebServlet("/usuario/cesta")
public class Cesta extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Cesta() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = request.getSession().getAttribute("username").toString();

			Client client = ClientBuilder.newClient();
	        
	        WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/usuarios/"+username);
	        String respuesta = OrderByIdTarget.request().get(String.class);
	        
	        if (respuesta == "null") {
	        	throw new Exception();
	        }
	        
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        
	        String carrito = json.get("carrito").toString();
	        
	        String tabla = "";
	        String comprar = "";
	        String vaciarCarrito = "";
	        String cestaVacia = "<h1 class=\"text-center\">No hay productos en la cesta</h1>";
	        if (carrito.length() != 0){
	        	
	        	// Traemos los alamacenes para poner su nombre
		        OrderByIdTarget = client.target(
						"http://localhost:8080/catalogoJuguetes/rest/almacenes");
			    respuesta = OrderByIdTarget.request().get(String.class);
			        
		        JSONArray jsonls = (JSONArray) JSONValue.parse(respuesta);
		        HashMap<Integer, String> almacenes = new HashMap<Integer, String>();
		        
		        Iterator lista = jsonls.iterator();
		        while (lista.hasNext())  
		        { 
		        	JSONObject objeto = (JSONObject)lista.next();
		        	almacenes.put(Integer.parseInt(objeto.get("id").toString()), objeto.get("nombre").toString());
		        } 
	        	
		        // Juguetes 
		        String[] elementos = carrito.split(";");
		        
		        for (String s : elementos) {
					String[] bin = s.split(",");
					int id = Integer.parseInt(bin[0]);
					int unidades = Integer.parseInt(bin[1]);
					OrderByIdTarget = client.target(
							"http://localhost:8080/catalogoJuguetes/rest/juguetes/"+id);
				    respuesta = OrderByIdTarget.request().get(String.class);
				        
			        if (respuesta == "null") {
			        	throw new Exception();
			        }
				        
				    json = (JSONObject) JSONValue.parse(respuesta);
				    
				    tabla += "<tr>";
				    tabla += "<td>" + json.get("nombre").toString() + "</td>";
				    tabla += "<td>" + almacenes.get(Integer.parseInt(json.get("almacen").toString())) + "</td>";
				    tabla += "<td>" + unidades + "</td>";
				    tabla += "<td>" + Double.parseDouble(json.get("precio").toString())*unidades + "</td>";
				    tabla += "<td><a class=\"btn btn-outline-danger\" href=\"remCarrito?id=" + id + 
							"\" role=\"button\">Borrar unidad</a></td>";
				    tabla += "</tr>";
				}
		        comprar = "<a class=\"btn btn-primary float-right\" href=\"/catalogoJuguetes/usuario/comprar\" role=\"button\">Comprar</a>";
		        vaciarCarrito = "<a class=\"btn btn-danger float-left\" href=\"/catalogoJuguetes/usuario/vaciarCarrito\" role=\"button\">Vaciar carrito</a>";
		        cestaVacia = "";
	        }
	        request.setAttribute("tabla", tabla);
	        request.setAttribute("comprar", comprar);
	        request.setAttribute("vaciarCarrito", vaciarCarrito);
	        request.setAttribute("cestaVacia", cestaVacia);
	        
	        RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/templates/cesta.jsp");
	        dispatcher.forward(request, response);
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/usuario/perfil.jsp");
		}
	}

}
