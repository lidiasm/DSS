package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import modelo.Almacen;

/**
 * Servlet implementation class AlmacenesList
 */
@WebServlet("/almacenes")
public class AlmacenesList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AlmacenesList() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			int rol = -1;
			if(request.getSession().getAttribute("rol") != null) {
				rol = Integer.parseInt(request.getSession().getAttribute("rol").toString());
			}
			
			Client client = ClientBuilder.newClient();
			WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/almacenes");
	        String respuesta = OrderByIdTarget.request().get(String.class);
	        
	        JSONArray json = (JSONArray) JSONValue.parse(respuesta);
	        List<Almacen> l = new ArrayList<Almacen>();
	        
	        Iterator lista = json.iterator();
	        while (lista.hasNext())  
	        { 
	        	JSONObject objeto = (JSONObject)lista.next();
	        	l.add(new Almacen(
	        			Integer.parseInt(objeto.get("id").toString()), 
	        			objeto.get("nombre").toString(), 
	        			objeto.get("direccion").toString(),
	        			Double.parseDouble(objeto.get("lat").toString()), 
	        			Double.parseDouble(objeto.get("lon").toString())
	        			)
	        		);
	        } 
			
			String tabla = "";
			for (Almacen a : l) {
				tabla += "<tr>"
						+ "<td>" + a.getId() + "</td>"
						+ "<td>" + a.getNombre() + "</td>"
						+ "<td>" + a.getDireccion() + "</td>"
						+ "<td>"+ a.getLat() + "</td>"
						+ "<td>" + a.getLon() + "</td>";
						if (rol == 0) {
							tabla += "<td><a href=\"eliminarAlmacen?id="+Integer.toString(a.getId())+"\"><i class=\"octicon octicon-trashcan\"></i></a>"
								+"<a style='padding-left:20px' href=\"editarAlmacen?id="+Integer.toString(a.getId())+"\"><i class=\"octicon octicon-pencil\"></i></a></td>";
						}
				tabla += "</tr>";
			}
			String crearBTN = "";
			if(rol == 0) {
				crearBTN = "<a class=\"btn btn-info\" href=\"forms/crear_almacen.jsp\" role=\"button\">Crear almacén</a>\n";
				
			}
			
			// Para el mapa
			OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/almacenes");
			respuesta = OrderByIdTarget.request().get(String.class);
			json = (JSONArray) JSONValue.parse(respuesta);
	        Iterator ita = json.iterator();
			String jsonMapa = "[";
	        while (ita.hasNext())  
	        { 
	        	JSONObject objeto = (JSONObject)ita.next();
				jsonMapa += "{\"nombre\":\""+objeto.get("nombre").toString()
						+"\",\"lat\":\""+Double.parseDouble(objeto.get("lat").toString())
						+"\",\"lon\":\""+Double.parseDouble(objeto.get("lon").toString())+"\"},";
	        } 
			jsonMapa += "]";
			request.setAttribute("jsonMapa", jsonMapa);
			
			String jsonUsuario = "null";
			if(request.getSession().getAttribute("rol") != null &&
					Integer.parseInt(request.getSession().getAttribute("rol").toString()) == 1) {
		        OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/usuarios/"+
							request.getSession().getAttribute("username").toString());
		        respuesta = OrderByIdTarget.request().get(String.class);
		        JSONObject usuario = (JSONObject) JSONValue.parse(respuesta);
		        jsonUsuario = "{"
		                + "\"nombre\":\"" + usuario.get("username").toString() + "\","
		                + "\"lat\":\"" + usuario.get("lat").toString() + "\","
		                + "\"lon\":\""+ usuario.get("lon").toString() + "\""
		                + "}";
			}
			request.setAttribute("jsonUsuario", jsonUsuario);
			// Fin del mapa

			request.setAttribute("tabla", tabla);
			request.setAttribute("crearBTN", crearBTN);
			
			RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/templates/almacenes.jsp");
	        dispatcher.forward(request, response);
		} catch (Exception e) {
			//e.printStackTrace();
		}
	}
	
}
