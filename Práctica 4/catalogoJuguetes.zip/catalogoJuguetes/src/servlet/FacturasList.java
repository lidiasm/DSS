package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

/**
 * Servlet implementation class FacturasList
 */
@WebServlet("/usuario/facturas")
public class FacturasList extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public FacturasList() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			String username = request.getSession().getAttribute("username").toString();

			Client client = ClientBuilder.newClient();
	        WebTarget OrderByIdTarget;
	        String respuesta;
	        
        	// Traemos los alamacenes para poner su nombre
	        OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/almacenes");
		    respuesta = OrderByIdTarget.request().get(String.class);
	        JSONArray jsonls = (JSONArray) JSONValue.parse(respuesta);
	        HashMap<Integer, String> almacenes = new HashMap<Integer, String>();
	        Iterator lista = jsonls.iterator();
	        while (lista.hasNext())  
	        { 
	        	JSONObject objeto = (JSONObject)lista.next();
	        	almacenes.put(Integer.parseInt(objeto.get("id").toString()), objeto.get("nombre").toString());
	        }
	        
	        // Traemos las facturas
	        OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/facturas/username/"+username);
		    respuesta = OrderByIdTarget.request().get(String.class);
	        jsonls = (JSONArray) JSONValue.parse(respuesta);
	        
	        lista = jsonls.iterator();
	        String tabla = "";
	        while (lista.hasNext())  
	        { 
	        	JSONObject factura = (JSONObject)lista.next();
	        	
	        	tabla += "<div class=\"row justify-content-md-center mt-3\">";
	        	tabla += "<div class=\"col-md-8\">";
	        	tabla += "<div class=\"row\">";
	        	tabla += "<div class=\"col-md-12\">";
	        	tabla += "<h3>Factura "+factura.get("id")+" "+factura.get("fechaEmision")+"</h3>";
	        	tabla += "</div>";
	        	tabla += "</div>";
	        	tabla += "<div class=\"row\">";
	        	tabla += "<div class=\"col-md-12\">";
	        	tabla += "<table style=\"width: 100%;\">";
	        	tabla += "<thead>";
	        	tabla += "<tr>";
	        	tabla += "<th scope=\"col\">Nombre producto</th>";
	        	tabla += "<th scope=\"col\">Almacén</th>";
	        	tabla += "<th scope=\"col\">Unidades</th>";
	        	tabla += "<th scope=\"col\">Precio</th>";
	        	tabla += "</tr>";
	        	tabla += "</thead>";
	        	tabla += "<tbody>";
	        	
	        	String comprados = factura.get("idJuguetesComprados").toString();
	        	String[] elementos = comprados.split(";");
		        for (String s : elementos) {
					String[] bin = s.split(",");
					int id = Integer.parseInt(bin[0]);
					int unidades = Integer.parseInt(bin[1]);
					
					OrderByIdTarget = client.target(
							"http://localhost:8080/catalogoJuguetes/rest/juguetes/"+id);
				    respuesta = OrderByIdTarget.request().get(String.class);
				    JSONObject juguete = (JSONObject) JSONValue.parse(respuesta);
				    
				    tabla += "<tr>";
		        	tabla += "<td>"+juguete.get("nombre")+"</td>";
		        	tabla += "<td>"+almacenes.get(Integer.parseInt(juguete.get("almacen").toString()))+"</td>";
		        	tabla += "<td>"+unidades+"</td>";
		        	tabla += "<td>"+juguete.get("precio")+"</td>";
		        	tabla += "</tr>";
				}
	        	
	        	tabla += "</tbody>";
	        	tabla += "</table>";
	        	tabla += "</div>";
	        	tabla += "</div>";
	        	tabla += "<div class=\"row\">";
	        	tabla += "<div class=\"col-md-12\">";
	        	tabla += "<h5 class=\"float-right\">Total: "+factura.get("precio")+"</h5>";
	        	if (factura.get("pagado").toString().equals("true")) {
	        		tabla += "Pagado: si<br/>";
	        	} else {
	        		tabla += "Pagado: no<br/>";
	        	}
	        	tabla += "Tipo de pago: "+factura.get("tipoPago")+"<br/>";
	        	tabla += "</div>";
	        	tabla += "</div>";
	        	tabla += "</div>";
	        	tabla += "</div>";
	        }
	        
	        request.setAttribute("tabla", tabla);
	        RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/templates/facturas.jsp");
	        dispatcher.forward(request, response);
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/usuario/perfil.jsp");
		}
	}

}
