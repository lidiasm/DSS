package servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

@WebServlet("/crearJuguete")
public class CrearJuguete extends HttpServlet {

	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrearJuguete() {
        super();
    }

    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			// Obtenemos los parámetros
			String nombre = (String) request.getParameter("nombre");
			String descripcion = (String) request.getParameter("descripcion");
			String precio = (String) request.getParameter("precio");
			String minEdad = (String) request.getParameter("edad");
			String almacen = (String) request.getParameter("almacen");
			String unidades = (String) request.getParameter("unidades");
			Client client = ClientBuilder.newClient();
	        
	        WebTarget OrderByIdTarget = client.target(
				"http://localhost:8080/catalogoJuguetes/rest/juguetes");
	        String jsonEnvio = "{";
	        jsonEnvio += "\"nombre\": \""+nombre+"\",";
	        jsonEnvio += "\"descripcion\": \""+descripcion+"\",";
	        jsonEnvio += "\"minEdadRecomendada\": \""+minEdad+"\",";
	        jsonEnvio += "\"precio\": \""+precio+"\",";
	        jsonEnvio += "\"almacen\": \""+almacen+"\",";
	        jsonEnvio += "\"unidades\": \""+unidades+"\"";
	        jsonEnvio += "}";
	        Response res = OrderByIdTarget.request(MediaType.APPLICATION_JSON).post(Entity.json(jsonEnvio));
	        String respuesta = res.readEntity(String.class);
	        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
	        boolean created = json.get("created").toString() == "true";
	        
	        if (!created) {
	        	throw new Exception();
	        }
	        
	        response.sendRedirect("/catalogoJuguetes/juguetes");
	        
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}
}
