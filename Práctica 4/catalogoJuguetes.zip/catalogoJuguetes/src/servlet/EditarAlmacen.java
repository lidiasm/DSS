package servlet;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import modelo.Almacen;

@WebServlet(urlPatterns = { "/editarAlmacen" })
public class EditarAlmacen extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private String idAlmacen = "";
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditarAlmacen() {
        super();
    }
    
    /**
     * Método que recopila la información asociada al almacén y la muestra en el formulario.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	request.setCharacterEncoding("UTF-8");
    	// Obtenemos el almacén
    	idAlmacen = (String) request.getParameter("id");
    	Client client = ClientBuilder.newClient();
		WebTarget OrderByIdTarget = client.target(
			"http://localhost:8080/catalogoJuguetes/rest/almacenes/"+idAlmacen);
        String respuesta = OrderByIdTarget.request().get(String.class);
        
        JSONObject objeto = (JSONObject) JSONValue.parse(respuesta);
    	Almacen almacenAEditar = new Almacen(
    			Integer.parseInt(objeto.get("id").toString()), 
    			objeto.get("nombre").toString(), 
    			objeto.get("direccion").toString(),
    			Double.parseDouble(objeto.get("lat").toString()), 
    			Double.parseDouble(objeto.get("lon").toString())
    			);
        
        // Mostramos los datos en el form
        request.setAttribute("almacen", almacenAEditar);
        
        RequestDispatcher dispatcher = request.getServletContext()
                .getRequestDispatcher("/forms/editar_almacen.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Método que recopila la información del formulario y actualiza el almacén.
     */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			request.setCharacterEncoding("UTF-8");
			// Obtenemos los parámetros
			String nombre = (String) request.getParameter("nombre");
			String direccion = (String) request.getParameter("direccion");
			String lat = (String) request.getParameter("lat");
			String lon = (String) request.getParameter("lon");
			
			Client client = ClientBuilder.newClient();
	        
			if (idAlmacen != "") {
		        WebTarget OrderByIdTarget = client.target(
					"http://localhost:8080/catalogoJuguetes/rest/almacenes/"+idAlmacen);
		        String jsonEnvio = "{";
		        jsonEnvio += "\"nombre\": \""+nombre+"\",";
		        jsonEnvio += "\"direccion\": \""+direccion+"\",";
		        jsonEnvio += "\"lat\": \""+lat+"\",";
		        jsonEnvio += "\"lon\": \""+lon+"\"";
		        jsonEnvio += "}";
		        Response res = OrderByIdTarget.request(MediaType.APPLICATION_JSON).post(Entity.json(jsonEnvio));
		        String respuesta = res.readEntity(String.class);
		        JSONObject json = (JSONObject) JSONValue.parse(respuesta);
		        boolean created = json.get("updated").toString() == "true";
		        
		        if (!created) {
		        	throw new Exception();
		        }
		        response.sendRedirect("/catalogoJuguetes/almacenes");
		        idAlmacen = "";
			}
			else
				response.sendRedirect("/catalogoJuguetes/almacenes");
		} catch (Exception e) {
			response.sendRedirect("/catalogoJuguetes/");
		}
	}
}


