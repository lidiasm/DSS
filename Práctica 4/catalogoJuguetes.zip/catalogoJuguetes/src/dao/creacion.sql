CREATE TABLE `dss`.`usuario` (
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(64) NOT NULL,
  `name` VARCHAR(250) NULL,
  `lat` DOUBLE NULL,
  `lon` DOUBLE NULL,
  `preferencias` VARCHAR(45) NULL,
  `carrito` VARCHAR(500) NULL,
  `rol` INT NOT NULL DEFAULT 1,
  PRIMARY KEY (`username`));

CREATE TABLE `dss`.`juguete` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `descripcion` VARCHAR(200) NULL,
  `minEdadRecomendada` INT NULL,
  `precio` DOUBLE NULL,
  `almacen` INT NULL,
  `unidades` INT NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `dss`.`almacen` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NULL,
  `direccion` VARCHAR(200) NULL,
  `lat` DOUBLE NULL,
  `lon` DOUBLE NULL,
  PRIMARY KEY (`id`));

CREATE TABLE `dss`.`factura` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `precio` DOUBLE NULL,
  `pagado` TINYINT NULL,
  `idJuguetesComprados` VARCHAR(200) NULL,
  `fechaEmision` VARCHAR(45) NULL,
  `username` VARCHAR(50) NOT NULL,
  `tipoPago` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));