package modelo;

public class Factura {
	private int id;
	private double precio;
	private boolean pagado;
	private String idJuguetesComprados;
	private String fechaEmision;
	private String username;
	private String tipoPago;
	
	public Factura() {}
	
	public Factura(double precio, boolean pagado, String idJuguetesComprados, String fechaEmision, String username, String tipoPago) {
		this.pagado = pagado;
		this.idJuguetesComprados = idJuguetesComprados;
		this.fechaEmision = fechaEmision;
		this.precio = precio;
		this.username = username;
		this.tipoPago = tipoPago;
	}
	
	public Factura(int id, double precio, boolean pagado, String idJuguetesComprados, String fechaEmision, String username, String tipoPago) {
		this.id = id;
		this.pagado = pagado;
		this.idJuguetesComprados = idJuguetesComprados;
		this.fechaEmision = fechaEmision;
		this.precio = precio;
		this.username = username;
		this.tipoPago = tipoPago;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public boolean getPagado() {
		return pagado;
	}
	
	public void setPagado(boolean pagado) {
		this.pagado = pagado;
	}
	
	public String getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	
	public String getIdJuguetesComprados() {
		return idJuguetesComprados;
	}
	public void setIdJuguetesComprados(String idJuguetesComprados) {
		this.idJuguetesComprados = idJuguetesComprados;
	}
	
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getTipoPago() {
		return tipoPago;
	}
	public void setTipoPago(String tipoPago) {
		this.tipoPago = tipoPago;
	}
	
	public String toString() {
		String resultado = "\nFecha de emisión: " + fechaEmision + "\nEmitida a: " + username+ "\nPrecio: " + precio +"\nTipo de pago: "+tipoPago;
		if (pagado) resultado += "\nPagada: Sí";
		else resultado += "\nPagada: No";
		resultado += "\nIds de los juguetes comprados: "+idJuguetesComprados;
		return resultado;
	}
}
