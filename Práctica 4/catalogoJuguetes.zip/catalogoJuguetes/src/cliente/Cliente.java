package cliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.List;
import java.util.Scanner;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriBuilder;

import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.core.util.MultivaluedMapImpl;

import dao.DbConnection;
import dao.FacturaDao;
import dao.JugueteDao;
import modelo.Juguete;
import modelo.Usuario;
import modelo.Almacen;
import modelo.Factura;

public class Cliente {

	public static void main(String[] args) throws Exception {
		// Cliente
		ClientConfig config = new DefaultClientConfig();
		Client cliente = Client.create(config);
		WebResource servicio = cliente.resource(getBaseURI());
		// Lectura de datos
		Scanner es = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int opcion = 0;
		while (opcion != -1) {
			System.out.println("\nBievenido al catálogo de Juguetes.\nElija la entidad con la que desea realizar operaciones.");
			System.out.println("1)Usuarios \n2)Juguetes \n3)Facturas \n4)Almacenes \n-1)TERMINAR");
			System.out.print("Escoja una de las anteriores opciones: ");
			opcion = es.nextInt();
			// Comprobamos opción
			while (opcion < -1 || opcion > 4) {
				System.out.print("\nOpción incorrecta, por favor, escoja una de las anteriores opciones: ");
				opcion = es.nextInt();
			}
			switch(opcion) {
				case 1:
					////// USUARIOS
					System.out.println("\n1)Obtener todos los usuarios \n2)Obtener un usuario \n3)Iniciar sesión \n4)Crear un nuevo usuario"
							+ "\n5)Actualizar información de un usuario \n6)Eliminar un usuario");
					System.out.print("Escoja una de las opciones anteriores: ");
					opcion = es.nextInt();
					// Comprobamos opción
					while (opcion < 1 || opcion > 6) {
						System.out.print("\nOpción incorrecta, por favor, escoja una de las anteriores opciones: ");
						opcion = es.nextInt();
					}
					switch(opcion) {
						// Obtener usuarios
						case 1:
							System.out.println(servicio.path("rest").path("usuarios").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						// Obtener un usuario por su username que es el id
						case 2:
							System.out.println("Como ejemplo obtenemos el usuario cuyo username = carlos.");
							System.out.println(servicio.path("rest").path("usuarios").path("carlos").
								accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						// Iniciar sesión
						case 3:
							System.out.println("Como ejemplo iniciamos sesión con el usuario Carlos.");
							ClientResponse respuesta = servicio.path("rest").path("usuarios").path("login").path("Carlos").path("1234").
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).get(ClientResponse.class);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						// Nuevo usuario
						case 4:
							// Borramos el usuario si ya existe
							String usuario = servicio.path("rest").path("usuarios").path("prueba").
							accept(MediaType.APPLICATION_JSON).get(String.class);
							Gson g = new Gson();
							Usuario user = g.fromJson(usuario, Usuario.class);
							if (user != null) {
								servicio.path("rest").path("usuarios").path("prueba").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
							}
					
							System.out.println("Como ejemplo vamos a crear un usuario con username = prueba");
							String parametros = "{\"username\":\"prueba\",\"password\":\"12345\"}";
							respuesta = servicio.path("rest").path("usuarios").
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						// Actualizar info de usuario
						case 5:
							System.out.println("Como ejemplo, vamos a actualizar el nombre del usuario anterior.");
							System.out.print("Introduzca el nombre completo para el usuario 'prueba': ");
							String name = "";
							name = br.readLine();
							while (name == "") {
								System.out.print("Introduzca el nombre completo para el usuario 'prueba': ");
								name = br.readLine();
							}
							// Creamos el usuario si no existe
							usuario = servicio.path("rest").path("usuarios").path("prueba").
									accept(MediaType.APPLICATION_JSON).get(String.class);
							g = new Gson();
							user = g.fromJson(usuario, Usuario.class);
							if (user == null) {
								parametros = "{\"username\":\"prueba\",\"password\":\"12345\"}";
								servicio.path("rest").path("usuarios").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							}
							
							parametros = "{\"name\":\""+name+"\"}";
							respuesta = servicio.path("rest").path("usuarios").path("prueba").
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						// Eliminar usuario
						case 6:
							// Creamos el usuario si no existe
							usuario = servicio.path("rest").path("usuarios").path("prueba").
									accept(MediaType.APPLICATION_JSON).get(String.class);
							g = new Gson();
							user = g.fromJson(usuario, Usuario.class);
							if (user == null) {
								parametros = "{\"username\":\"prueba\",\"password\":\"12345\"}";
								servicio.path("rest").path("usuarios").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							}
							
							System.out.println("Como ejemplo, vamos a eliminar al usuario creado en el caso 4: 'prueba'");
							respuesta = servicio.path("rest").path("usuarios").path("prueba").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
					}
				break;
				case 2:
					///// JUGUETES
					System.out.println("\n1)Obtener todos los juguetes \n2)Obtener todos los juguetes de un almacén \n3)Obtener un juguete"
							+ "\n4)Crear un nuevo juguete \n5)Actualizar información de un juguete \n6)Eliminar un juguete");
					System.out.print("Escoja una de las opciones anteriores: ");
					opcion = es.nextInt();
					// Comprobamos opción
					while (opcion < 1 || opcion > 6) {
						System.out.print("\nOpción incorrecta, por favor, escoja una de las anteriores opciones: ");
						opcion = es.nextInt();
					}
					switch(opcion) {
						// Obtener juguetes
						case 1:
							System.out.println(servicio.path("rest").path("juguetes").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						// Obtener juguetes de un almacén
						case 2:
							System.out.println("Como ejemplo obtenemos los juguetes del almacén 2.");
							System.out.println(servicio.path("rest").path("juguetes").path("almacen").path("2").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						// Obtener un juguete
						case 3:
							System.out.println("Como ejemplo obtenemos el juguete con id=2.");
							System.out.println(servicio.path("rest").path("juguetes").path("2").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						// Crear nuevo juguete
						case 4:
							// Borramos el juguete si ya existe
							String juguete = servicio.path("rest").path("juguetes").path("nombre").path("MyLittlePony").accept(MediaType.APPLICATION_JSON).get(String.class);
							Gson g = new Gson();
							Juguete j = g.fromJson(juguete, Juguete.class);
							if (j != null) {
								servicio.path("rest").path("juguetes").path(Integer.toString(j.getId())).
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
							}
							
							System.out.println("Como ejemplo creamos el juguete MyLittlePony");
							String parametros = "{\"nombre\":\"MyLittlePony\",\"descripcion\":\"Peluche\",\"precio\":\"39.99\",\"almacen\":\"2\"}";
							ClientResponse respuesta = servicio.path("rest").path("juguetes").
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						// Actualizar juguete
						case 5:
							// Obtenemos el juguete creado en el apartado anterior
							juguete = servicio.path("rest").path("juguetes").path("nombre").path("MyLittlePony").accept(MediaType.APPLICATION_JSON).get(String.class);
							g = new Gson();
							j = g.fromJson(juguete, Juguete.class);
							// Creamos el juguete si no existe
							if (j == null) {
								parametros = "{\"nombre\":\"MyLittlePony\",\"descripcion\":\"Peluche\",\"precio\":\"39.99\",\"almacen\":\"2\"}";
								servicio.path("rest").path("juguetes").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
								juguete = servicio.path("rest").path("juguetes").path("nombre").path("MyLittlePony").accept(MediaType.APPLICATION_JSON).get(String.class);
								j = g.fromJson(juguete, Juguete.class);
							}
							System.out.println("Como ejemplo, vamos a actualizar el juguete creado anteriormente.");
							System.out.print("Introduza el número de unidades de este juguete: ");
							String unidades = "";
							unidades = br.readLine();
							while (unidades == "") {
								System.out.print("Introduza el número de unidades de este juguete: ");
								unidades = br.readLine();
							}
							parametros = "{\"unidades\":\""+unidades+"\"}";
							respuesta = servicio.path("rest").path("juguetes").path(Integer.toString(j.getId())).
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						// Eliminar juguete
						case 6:
							// Obtenemos el juguete creado en el apartado anterior
							juguete = servicio.path("rest").path("juguetes").path("nombre").path("MyLittlePony").accept(MediaType.APPLICATION_JSON).get(String.class);
							g = new Gson();
							j = g.fromJson(juguete, Juguete.class);
							// Creamos el juguete si no existe
							if (j == null) {
								parametros = "{\"nombre\":\"MyLittlePony\",\"descripcion\":\"Peluche\",\"precio\":\"39.99\",\"almacen\":\"2\"}";
								servicio.path("rest").path("juguetes").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
								juguete = servicio.path("rest").path("juguetes").path("nombre").path("MyLittlePony").accept(MediaType.APPLICATION_JSON).get(String.class);
								j = g.fromJson(juguete, Juguete.class);
							}
							System.out.println("Como ejemplo, vamos a eliminar el juguete creado anteriormente.");
							respuesta = servicio.path("rest").path("juguetes").path(Integer.toString(j.getId())).
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
					}
				break;
				case 3:
					///// FACTURAS
					System.out.println("\n1)Obtener todas las facturas \n2)Obtener una factura por su id \n3)Obtener el número de facturas creadas"
							+ "\n4)Crear una nueva factura \n5)Actualizar una factura \n6)Eliminar una factura");
					System.out.print("Escoja una de las opciones anteriores: ");
					opcion = es.nextInt();
					// Comprobamos opción
					while (opcion < 1 || opcion > 6) {
						System.out.print("\nOpción incorrecta, por favor, escoja una de las anteriores opciones: ");
						opcion = es.nextInt();
					}
					Factura nuevaFactura = null;
					switch(opcion) {
						case 1:
							// Obtener todas las facturas
							System.out.println(servicio.path("rest").path("facturas").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						case 2:
							// Obtener una factura por su id
							System.out.println("Como ejemplo vamos a obtener los datos de la factura con id=1");
							System.out.println(servicio.path("rest").path("facturas").path("1").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						case 3:
							// Obtener el número de facturas
							System.out.println("Número de facturas: "+servicio.path("rest").path("facturas").
								path("count").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						case 4:
							// Crear una factura
							System.out.println("Como ejemplo vamos a generar una factura por la compra de los dos primeros juguetes a nombre del usuario Carlos.");
							List<Juguete> juguetes = JugueteDao.getAll(DbConnection.getConnection());
							String idsJuguetes = Integer.toString(juguetes.get(0).getId()) + ";" +
								Integer.toString(juguetes.get(1).getId()) + ";";
							double precio = juguetes.get(0).getPrecio() + juguetes.get(1).getPrecio();
							nuevaFactura = new Factura(precio, false, idsJuguetes, "03-01-2020", "Carlos", "transferencia");
							nuevaFactura = FacturaDao.create(DbConnection.getConnection(), nuevaFactura);
							System.out.println("Factura creada: "+nuevaFactura.toString());
						break;
						case 5:
							// Actualizar una factura
							System.out.println("Como ejemplo vamos a actualizar una factura de compra de los dos primeros juguetes a nombre del usuario Carlos.");
							// Si no existe la factura la creamos
							if (nuevaFactura == null) {
								juguetes = JugueteDao.getAll(DbConnection.getConnection());
								idsJuguetes = Integer.toString(juguetes.get(0).getId()) + ";" +
									Integer.toString(juguetes.get(1).getId()) + ";";
								precio = juguetes.get(0).getPrecio() + juguetes.get(1).getPrecio();
								nuevaFactura = new Factura(precio, false, idsJuguetes, "03-01-2020", "Carlos", "transferencia");
								nuevaFactura = FacturaDao.create(DbConnection.getConnection(), nuevaFactura);
							}
							// Modificamos la factura
							nuevaFactura.setPagado(true);
							nuevaFactura.setPrecio(1000);
							System.out.println("Factura modificada: "+nuevaFactura.toString());
						break;
						case 6:
							// Eliminar una factura
							System.out.println("Como ejemplo vamos a eliminar la factura de compra de los dos primeros juguetes a nombre del usuario Carlos.");
							// Si no existe la factura la creamos
							if (nuevaFactura == null) {
								juguetes = JugueteDao.getAll(DbConnection.getConnection());
								idsJuguetes = Integer.toString(juguetes.get(0).getId()) + ";" +
									Integer.toString(juguetes.get(1).getId()) + ";";
								precio = juguetes.get(0).getPrecio() + juguetes.get(1).getPrecio();
								nuevaFactura = new Factura(precio, false, idsJuguetes, "03-01-2020", "Carlos", "transferencia");
								nuevaFactura = FacturaDao.create(DbConnection.getConnection(), nuevaFactura);
							}
							boolean resultado = FacturaDao.delete(DbConnection.getConnection(), nuevaFactura);
							if (resultado) System.out.println("La factura se ha eliminado correctamente.");
							else System.out.println("Error. La factura no se ha podido eliminar.");
						break;
					}
				break;
				case 4:
					//// ALMACENES
					System.out.println("\n1)Obtener todos los almacenes \n2)Obtener un almacén por su id \n3)Crear un nuevo almacén"
							+ "\n4)Actualizar información de un almacén \n5)Borrar un almacén");
					System.out.print("Escoja una de las opciones anteriores: ");
					opcion = es.nextInt();
					// Comprobamos opción
					while (opcion < 1 || opcion > 5) {
						System.out.print("\nOpción incorrecta, por favor, escoja una de las anteriores opciones: ");
						opcion = es.nextInt();
					}
					switch(opcion) {
						case 1:
							// Obtener todos los almacenes
							System.out.println(servicio.path("rest").path("almacenes").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						case 2:
							// Obtener un almacén por su id
							System.out.println("Como ejemplo obtenemos la información del almacen con id=1");
							System.out.println(servicio.path("rest").path("almacenes").path("1").accept(MediaType.APPLICATION_JSON).get(String.class));
						break;
						case 3:
							// Borramos el almacén si ya existe
							String almacen = servicio.path("rest").path("almacenes").path("nombre").path("Prueba").accept(MediaType.APPLICATION_JSON).get(String.class);
							Gson g = new Gson();
							Almacen al = g.fromJson(almacen, Almacen.class);
							if (al != null) {
								servicio.path("rest").path("almacenes").path(Integer.toString(al.getId())).
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
							}
							// Crear un almacén
							System.out.println("Como ejemplo creamos el almacén 'Prueba'");
							String parametros = "{\"nombre\":\"Prueba\",\"direccion\":\"Sevilla\"}";
							ClientResponse respuesta = servicio.path("rest").path("almacenes").
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						case 4:
							// Actualizar información de un almacén
							almacen = servicio.path("rest").path("almacenes").path("nombre").path("Prueba").accept(MediaType.APPLICATION_JSON).get(String.class);
							g = new Gson();
							al = g.fromJson(almacen, Almacen.class);
							// Creamos el almacén si no existe
							if (al == null) {
								parametros = "{\"nombre\":\"Prueba\",\"direccion\":\"Sevilla\"}";
								servicio.path("rest").path("almacenes").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
								almacen = servicio.path("rest").path("almacenes").path("nombre").path("Prueba").accept(MediaType.APPLICATION_JSON).get(String.class);
								al = g.fromJson(almacen, Almacen.class);
							}
							System.out.println("Como ejemplo, vamos a actualizar el almacén 'Prueba'.");
							System.out.print("Introduza una nueva dirección para el almacén: ");
							String direccion = "";
							direccion = br.readLine();
							while (direccion == "") {
								System.out.print("Introduza una nueva dirección para el almacén: ");
								direccion = br.readLine();
							}
							parametros = "{\"direccion\":\""+direccion+"\"}";
							respuesta = servicio.path("rest").path("almacenes").path(Integer.toString(al.getId())).
								accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
						case 5:
							// Eliminar almacén
							almacen = servicio.path("rest").path("almacenes").path("nombre").path("Prueba").accept(MediaType.APPLICATION_JSON).get(String.class);
							g = new Gson();
							al = g.fromJson(almacen, Almacen.class);
							// Creamos el almacén si no existe
							if (al == null) {
								parametros = "{\"nombre\":\"Prueba\",\"direccion\":\"Sevilla\"}";
								servicio.path("rest").path("almacenes").
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).post(ClientResponse.class, parametros);
								almacen = servicio.path("rest").path("almacenes").path("nombre").path("Prueba").accept(MediaType.APPLICATION_JSON).get(String.class);
								al = g.fromJson(almacen, Almacen.class);
							}
							System.out.println("Como ejemplo, vamos a eliminar el almacén 'Prueba'.");
							respuesta = servicio.path("rest").path("almacenes").path(Integer.toString(al.getId())).
									accept(MediaType.APPLICATION_JSON).type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
							System.out.println(respuesta + respuesta.getEntity(String.class));
						break;
					}
				break;
				case -1:
					System.out.println("FIN DE LA EJECUCIÓN");
				break;
			}
		}
	}
	
	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/catalogoJuguetes/").build();
	}
}
